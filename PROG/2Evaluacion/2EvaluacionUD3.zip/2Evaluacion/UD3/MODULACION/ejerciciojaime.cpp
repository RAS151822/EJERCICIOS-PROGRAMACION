#include <iostream>
using namespace std;

void intercambiar (int x, int y){
	int aux;

	x = aux;
	y = x;

}

int main () {
	int a = 2, b = 1;
	//intercambiar ();


	cout << a << " y " << b << endl;

}
